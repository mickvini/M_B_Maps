version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "yin-yang",
    description = "",
    preview = '',
    map_version = 3,
    type = 'skirmish',
    starts = true,
    size = {1024, 1024},
    reclaim = {84263, 22116},
    map = '/maps/yin-yang.v0003/yin-yang.scmap',
    save = '/maps/yin-yang.v0003/yin-yang_save.lua',
    script = '/maps/yin-yang.v0003/yin-yang_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
