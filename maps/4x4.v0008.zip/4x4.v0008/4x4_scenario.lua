version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "4x4",
    description = "",
    preview = '',
    map_version = 8,
    type = 'skirmish',
    starts = true,
    size = {2048, 2048},
    reclaim = {12657, 9920},
    map = '/maps/4x4.v0008/4x4.scmap',
    save = '/maps/4x4.v0008/4x4_save.lua',
    script = '/maps/4x4.v0008/4x4_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6', 'ARMY_7', 'ARMY_8'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
