version = 3
ScenarioInfo = {
    name = 'Winter Twin Rivers',
    description = 'Original map by Jiday. Frozen by Tokyto',
    type = 'skirmish',
    starts = true,
    preview = '',
    size = {512, 512},
    map = '/maps/Winter twin rivers.v0001/winter twin rivers.scmap',
    save = '/maps/Winter twin rivers.v0001/winter twin rivers_save.lua',
    script = '/maps/Winter twin rivers.v0001/winter twin rivers_script.lua',
    norushradius = 70.000000,
    norushoffsetX_ARMY_1 = 0.000000,
    norushoffsetY_ARMY_1 = -2.000000,
    norushoffsetX_ARMY_2 = 3.000000,
    norushoffsetY_ARMY_2 = 1.000000,
    norushoffsetX_ARMY_3 = 1.000000,
    norushoffsetY_ARMY_3 = 2.000000,
    norushoffsetX_ARMY_4 = -2.000000,
    norushoffsetY_ARMY_4 = -1.000000,
    norushoffsetX_ARMY_5 = 16.000000,
    norushoffsetY_ARMY_5 = -5.000000,
    norushoffsetX_ARMY_6 = -14.000000,
    norushoffsetY_ARMY_6 = 4.000000,
    Configurations = {
        ['standard'] = {
            teams = {
                { name = 'FFA', armies = {'ARMY_1','ARMY_2','ARMY_3','ARMY_4','ARMY_5','ARMY_6',} },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_9 NEUTRAL_CIVILIAN' ),
            },
        },
    }}
