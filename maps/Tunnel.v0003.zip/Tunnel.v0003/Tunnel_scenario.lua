version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "Tunnel",
    description = "",
    preview = '',
    map_version = 3,
    type = 'skirmish',
    starts = true,
    size = {1024, 1024},
    reclaim = {29495, 306},
    map = '/maps/Tunnel.v0003/Tunnel.scmap',
    save = '/maps/Tunnel.v0003/Tunnel_save.lua',
    script = '/maps/Tunnel.v0003/Tunnel_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
