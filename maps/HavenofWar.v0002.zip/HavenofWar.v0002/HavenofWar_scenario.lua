version = 4
ScenarioInfo = {
    name = 'Haven of War Beta',
    description = '<LOC HavenofWar_Description>When UEF refugees discovered a habitable world far from the warring front it quickly became known as a Safe haven for those discplced by the galactic stuggle. Over the years as the UEF military was pushed back they began refeuling on the small world. With the increased activity it wasnt long until other parties also learned of its presence. Now a visous struggle is taking place, such that what was once known as a haven, is now only known as a haven of war.',
    type = 'skirmish',
    starts = true,
    preview = '',
    size = {1024, 1024},
    map = '/maps/HavenofWar.v0002/HavenofWar.scmap',
    save = '/maps/HavenofWar.v0002/HavenofWar_save.lua',
    script = '/maps/HavenofWar.v0002/HavenofWar_script.lua',
	
	map_version=4,
	
    norushradius = 130.000000,
    norushoffsetX_ARMY_1 = 0.000000,
    norushoffsetY_ARMY_1 = 0.000000,
    norushoffsetX_ARMY_2 = 0.000000,
    norushoffsetY_ARMY_2 = 0.000000,
    norushoffsetX_ARMY_3 = 0.000000,
    norushoffsetY_ARMY_3 = 0.000000,
    norushoffsetX_ARMY_4 = 0.000000,
    norushoffsetY_ARMY_4 = 0.000000,
    norushoffsetX_ARMY_5 = 0.000000,
    norushoffsetY_ARMY_5 = 0.000000,
    norushoffsetX_ARMY_6 = 0.000000,
    norushoffsetY_ARMY_6 = 0.000000,
    Configurations = {
        ['standard'] = {
            teams = {
                { name = 'FFA', armies = {'ARMY_1','ARMY_2','ARMY_3','ARMY_4','ARMY_5','ARMY_6',} },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_9 NEUTRAL_CIVILIAN' ),
            },
        },
    }}
