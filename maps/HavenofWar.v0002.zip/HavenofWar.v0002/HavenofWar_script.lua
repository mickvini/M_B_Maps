-- imports
local ScenarioUtils = import('/lua/sim/ScenarioUtilities.lua')
local ScenarioFramework = import('/lua/ScenarioFramework.lua')

-- this function creates all mex and hydrocarbon markers
-- resource scale script (c) Jotto, reworked by tecxx
function ScenarioUtils.CreateResources()
   -- fetch markers and iterate them
   local markers = ScenarioUtils.GetMarkers();
   for i, tblData in pairs(markers) do
      -- spawn resources?
      local doit = false;
      if (tblData.resource and not tblData.SpawnWithArmy) then
         -- standard resources, spawn it
         doit = true;
      elseif (tblData.resource and tblData.SpawnWithArmy) then
         -- resources bound to player, check if army is presend
         for j, army in ListArmies() do
            if (tblData.SpawnWithArmy == army) then
               doit = true;  -- we made sure the army is present, allow spawn
               break;
            end
         end
      end
      
      if (doit) then
         -- check type of resource and set parameters
         local bp, albedo, sx, sz, lod;
         if tblData.type == "Mass" then
            albedo = "/env/common/splats/mass_marker.dds";
            bp = "/env/common/props/massDeposit01_prop.bp";
            sx = 2;
            sz = 2;
            lod = 100;
         else
            albedo = "/env/common/splats/hydrocarbon_marker.dds";
            bp = "/env/common/props/hydrocarbonDeposit01_prop.bp";
            sx = 6;
            sz = 6;
            lod = 200;
         end
         -- create the resource
         CreateResourceDeposit(tblData.type,   tblData.position[1], tblData.position[2], tblData.position[3], tblData.size);
         -- create the resource graphic on the map
         CreatePropHPR(bp, tblData.position[1], tblData.position[2], tblData.position[3], Random(0,360), 0, 0);
         -- create the resource icon on the map
         CreateSplat(
            tblData.position,           # Position
            0,                          # Heading (rotation)
            albedo,                     # Texture name for albedo
            sx, sz,                     # SizeX/Z
            lod,                        # LOD
            0,                          # Duration (0 == does not expire)
            -1,                         # army (-1 == not owned by any single army)
            0                     # ???
         );
      end
   end
end

function OnPopulate()
   ScenarioUtils.InitializeArmies()
   ScenarioFramework.SetPlayableArea('AREA_1', false)
end

function OnStart(self)

end 