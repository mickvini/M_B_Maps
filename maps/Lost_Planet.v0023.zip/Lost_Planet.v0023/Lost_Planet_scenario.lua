version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "Lost Planet",
    description = "",
    preview = '',
    map_version = 23,
    AdaptiveMap = true,
    type = 'skirmish',
    starts = true,
    size = {1024, 1024},
    reclaim = {160140.4, 12090},
    map = '/maps/Lost_Planet.v0023/Lost_Planet.scmap',
    save = '/maps/Lost_Planet.v0023/Lost_Planet_save.lua',
    script = '/maps/Lost_Planet.v0023/Lost_Planet_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6', 'ARMY_7'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
