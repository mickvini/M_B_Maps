version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "Zames",
    description = "",
    preview = '',
    map_version = 12,
    AdaptiveMap = true,
    type = 'skirmish',
    starts = true,
    size = {1024, 1024},
    reclaim = {168065.2, 0},
    map = '/maps/Zames.v0012/Zames.scmap',
    save = '/maps/Zames.v0012/Zames_save.lua',
    script = '/maps/Zames.v0012/Zames_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6', 'ARMY_7', 'ARMY_8'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
