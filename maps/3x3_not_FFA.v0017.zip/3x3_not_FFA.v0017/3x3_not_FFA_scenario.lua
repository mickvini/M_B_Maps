version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "3x3 not FFA",
    description = "",
    preview = '',
    map_version = 17,
    AdaptiveMap = true,
    type = 'skirmish',
    starts = true,
    size = {1024, 1024},
    reclaim = {152072, 91520},
    map = '/maps/3x3_not_FFA.v0017/3x3_not_FFA.scmap',
    save = '/maps/3x3_not_FFA.v0017/3x3_not_FFA_save.lua',
    script = '/maps/3x3_not_FFA.v0017/3x3_not_FFA_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
