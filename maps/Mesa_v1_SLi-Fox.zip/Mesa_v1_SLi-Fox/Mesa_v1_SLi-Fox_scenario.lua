version = 3
ScenarioInfo = {
  name = 'Mesa v1 SLi-Fox',
  type = 'skirmish',
  description = '<LOC Mesa_v1_SLi-Fox_Description>Crysis Mesa map by Crytek modded for SupComFA.',
  starts = true,
  preview = '',
  size = {2048, 2048},
  norushradius = 75,
  map = '/maps/Mesa_v1_SLi-Fox/Mesa_v1_SLi-Fox.scmap',
  save = '/maps/Mesa_v1_SLi-Fox/Mesa_v1_SLi-Fox_save.lua',
  script = '/maps/Mesa_v1_SLi-Fox/Mesa_v1_SLi-Fox_script.lua',
  Configurations = {
    ['standard'] = {
      teams = {
        {
          name = 'FFA',
          armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4'},
        },
      },
      customprops = {
        ['ExtraArmies'] = STRING( 'ARMY_9 NEUTRAL_CIVILIAN' ),
      },
    },
  },
  norushoffsetX_ARMY_1 = 0,
  norushoffsetY_ARMY_1 = 0,
  norushoffsetX_ARMY_2 = 0,
  norushoffsetY_ARMY_2 = 0,
  norushoffsetX_ARMY_3 = 0,
  norushoffsetY_ARMY_3 = 0,
  norushoffsetX_ARMY_4 = 0,
  norushoffsetY_ARMY_4 = 0,
}
