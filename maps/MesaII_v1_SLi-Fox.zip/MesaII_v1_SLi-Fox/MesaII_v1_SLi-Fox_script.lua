--[[
Don't edit or remove this comment block! It is used by the editor to store information since i'm too lazy to write a good LUA parser... -Haz
SETTINGS
RestrictedEnhancements=
RestrictedCategories=
END
--]]

local ScenarioUtils = import('/lua/sim/ScenarioUtilities.lua')
local ScenarioFramework = import('/lua/ScenarioFramework.lua')

# Resource Scale Script written by Jotto
function ScenarioUtils.CreateResources()
  local markers = ScenarioUtils.GetMarkers()
  for i, tblData in pairs(markers) do
    if tblData.resource and not tblData.SpawnWithArmy then
      CreateResourceDeposit(
        tblData.type,
        tblData.position[1], tblData.position[2], tblData.position[3],
        tblData.size
      )
      local albedo, sx, sz, lod
      if tblData.type == "Mass" then
        albedo = "/env/common/splats/mass_marker.dds"
        sx = 2
        sz = 2
        lod = 100
        CreatePropHPR(
          '/env/common/props/massDeposit01_prop.bp',
          tblData.position[1], tblData.position[2], tblData.position[3],
          Random(0,360), 0, 0
        )
      else
        albedo = "/env/common/splats/hydrocarbon_marker.dds"
        sx = 6
        sz = 6
        lod = 200
        CreatePropHPR(
          '/env/common/props/hydrocarbonDeposit01_prop.bp',
          tblData.position[1], tblData.position[2], tblData.position[3],
          Random(0,360), 0, 0
        )
      end
      CreateSplat(
        tblData.position,           # Position
        0,                          # Heading (rotation)
        albedo,                     # Texture name for albedo
        sx, sz,                     # SizeX/Z
        lod,                        # LOD
        0,                          # Duration (0 == does not expire)
        -1,                         # army (-1 == not owned by any single army)
        0
      )
    elseif tblData.resource and tblData.SpawnWithArmy then
      for a, v in ListArmies() do
        if tblData.SpawnWithArmy == v then
          CreateResourceDeposit(
            tblData.type,
            tblData.position[1], tblData.position[2], tblData.position[3],
            tblData.size
          )
          local albedo, sx, sz, lod
          if tblData.type == "Mass" then
            albedo = "/env/common/splats/mass_marker.dds"
            sx = 2
            sz = 2
            lod = 100
            CreatePropHPR(
              '/env/common/props/massDeposit01_prop.bp',
              tblData.position[1], tblData.position[2], tblData.position[3],
              Random(0,360), 0, 0
            )
          else
            albedo = "/env/common/splats/hydrocarbon_marker.dds"
            sx = 6
            sz = 6
            lod = 200
            CreatePropHPR(
              '/env/common/props/hydrocarbonDeposit01_prop.bp',
              tblData.position[1], tblData.position[2], tblData.position[3],
              Random(0,360), 0, 0
            )
          end
          CreateSplat(
            tblData.position,           # Position
            0,                          # Heading (rotation)
            albedo,                     # Texture name for albedo
            sx, sz,                     # SizeX/Z
            lod,                        # LOD
            0,                          # Duration (0 == does not expire)
            -1,                         # army (-1 == not owned by any single army)
            0
          )
        end
      end
    end
  end
end

function OnPopulate()
  ScenarioUtils.InitializeArmies()
end

function OnStart(self)
end
