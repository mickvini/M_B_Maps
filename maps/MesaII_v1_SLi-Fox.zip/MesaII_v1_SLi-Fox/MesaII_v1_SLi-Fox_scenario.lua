version = 3
ScenarioInfo = {
  name = 'Mesa II v1 by SLi-Fox',
  type = 'skirmish',
  description = '<LOC MesaII_v1_SLi-Fox_Description>I was inspired by the Crysis Mesa map.',
  starts = true,
  preview = '',
  size = {2048, 2048},
  norushradius = 525,
  map = '/maps/MesaII_v1_SLi-Fox/MesaII_v1_SLi-Fox.scmap',
  save = '/maps/MesaII_v1_SLi-Fox/MesaII_v1_SLi-Fox_save.lua',
  script = '/maps/MesaII_v1_SLi-Fox/MesaII_v1_SLi-Fox_script.lua',
  Configurations = {
    ['standard'] = {
      teams = {
        {
          name = 'FFA',
          armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4'},
        },
      },
      customprops = {
        ['ExtraArmies'] = STRING( 'ARMY_9 NEUTRAL_CIVILIAN' ),
      },
    },
  },
  norushoffsetX_ARMY_1 = 0,
  norushoffsetY_ARMY_1 = 0,
  norushoffsetX_ARMY_2 = 0,
  norushoffsetY_ARMY_2 = 0,
  norushoffsetX_ARMY_3 = 0,
  norushoffsetY_ARMY_3 = 0,
  norushoffsetX_ARMY_4 = 0,
  norushoffsetY_ARMY_4 = 0,
}
