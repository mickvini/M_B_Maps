version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "Twin Rivers by ASUSPRO",
    description = "",
    preview = '',
    map_version = 4,
    AdaptiveMap = true,
    type = 'skirmish',
    starts = true,
    size = {1024, 1024},
    reclaim = {18231.43, 14052.75},
    map = '/maps/Twin_Rivers_by_ASUSPRO.v0004/Twin_Rivers_by_ASUSPRO.scmap',
    save = '/maps/Twin_Rivers_by_ASUSPRO.v0004/Twin_Rivers_by_ASUSPRO_save.lua',
    script = '/maps/Twin_Rivers_by_ASUSPRO.v0004/Twin_Rivers_by_ASUSPRO_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6', 'ARMY_7', 'ARMY_8'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
