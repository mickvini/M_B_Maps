version = 3
ScenarioInfo = {
  name = 'Elysion_40k',
  type = 'skirmish',
  description = '<LOC elysion_40k_Description>',
  starts = true,
  preview = '',
  size = {2048, 2048},
  norushradius = 180,
  norushoffsetX_ARMY_1 = 0,
  norushoffsetY_ARMY_1 = 0,
  norushoffsetX_ARMY_2 = 0,
  norushoffsetY_ARMY_2 = 0,
  norushoffsetX_ARMY_3 = 0,
  norushoffsetY_ARMY_3 = 0,
  norushoffsetX_ARMY_4 = 0,
  norushoffsetY_ARMY_4 = 0,
  norushoffsetX_ARMY_5 = 0,
  norushoffsetY_ARMY_5 = 0,
  norushoffsetX_ARMY_6 = 0,
  norushoffsetY_ARMY_6 = 0,
  norushoffsetX_ARMY_7 = 0,
  norushoffsetY_ARMY_7 = 0,
  norushoffsetX_ARMY_8 = 0,
  norushoffsetY_ARMY_8 = 0,
  map = '/maps/elysion_40k/elysion_40k.scmap',
  save = '/maps/elysion_40k/elysion_40k_save.lua',
  script = '/maps/elysion_40k/elysion_40k_script.lua',
  Configurations = {
    ['standard'] = {
      teams = {
        { name = 'FFA', armies = {'ARMY_1','ARMY_2','ARMY_3','ARMY_4','ARMY_5','ARMY_6','ARMY_7','ARMY_8',} },
      },
      customprops = {
        ['ExtraArmies'] = STRING( 'ARMY_9 NEUTRAL_CIVILIAN' ),
      },
    },
  }}
