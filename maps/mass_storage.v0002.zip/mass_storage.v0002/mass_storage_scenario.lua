version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "mass storage",
    description = "",
    preview = '',
    map_version = 2,
    type = 'skirmish',
    starts = true,
    size = {1024, 1024},
    reclaim = {0, 0},
    map = '/maps/mass_storage.v0002/mass_storage.scmap',
    save = '/maps/mass_storage.v0002/mass_storage_save.lua',
    script = '/maps/mass_storage.v0002/mass_storage_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
