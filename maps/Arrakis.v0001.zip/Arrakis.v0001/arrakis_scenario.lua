version = 3
ScenarioInfo = {
  Configurations={
    standard={
      customprops={ },
      teams={
        {
          armies={ "ARMY_1", "ARMY_2", "ARMY_3", "ARMY_4", "ARMY_5", "ARMY_6" },
          name="FFA"
        }
      }
    }
  },
  description="The chances for a Commander to return from a mission on Dune are slim at best, violent storms reshape the landscape and maps are sometimes rendered useless in hours. Sand and heat cause equipment to fail and water can only be found at the poles. Despite all odds intelligence officers insist that the risk is well worth it although the Seraphim have shown interest in Dune lately. All rescue operations have been discontinued and missing Commanders are declared KIA after 24 hours...",
  map="/maps/Arrakis.v0001/arrakis.scmap",
  map_version=1,
  name="Desert Planet II XL",
  norushoffsetX_ARMY_1=0,
  norushoffsetX_ARMY_2=0,
  norushoffsetX_ARMY_3=0,
  norushoffsetX_ARMY_4=0,
  norushoffsetX_ARMY_5=0,
  norushoffsetX_ARMY_6=0,
  norushoffsetY_ARMY_1=0,
  norushoffsetY_ARMY_2=0,
  norushoffsetY_ARMY_3=0,
  norushoffsetY_ARMY_4=0,
  norushoffsetY_ARMY_5=0,
  norushoffsetY_ARMY_6=0,
  norushradius=150,
  preview="",
  save="/maps/Arrakis.v0001/Arrakis_save.lua",
  script="/maps/Arrakis.v0001/Arrakis_script.lua",
  size={ 1024, 1024 },
  starts=true,
  type="skirmish"
}
