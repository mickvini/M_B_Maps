Desert Planet II XL (Sup Com version 1.1.3251 and above, Forged Alliance)
Map Size: 20x20 km
Max Players: 6


#########################################################################################################

	How to install:
Extract the "Arrakis" folder into your "maps" folder.
The location of the Gates to Paradise.scmap should be:

[game dir]\THQ\Gas Powered Games\Supreme Commander\maps\Arrakis\Arrakis.scmap

[My Documents]\My Games\Gas Powered Games\SupremeCommander\maps\Arrakis\Arrakis.scmap
(the [My Documents]-path only works if you have enabled this path in Sup Coms options....)

#########################################################################################################

The chances for a Commander to return from a mission on Dune are slim at best, violent storms reshape the landscape and maps are sometimes rendered useless in hours. Sand and heat cause equipment to fail and water can only be found at the poles. Despite all odds intelligence officers insist that the risk is well worth it although the Seraphim have shown interest in Dune lately. All rescue operations have been discontinued and missing Commanders are declared KIA after 24 hours...

***************************

Author:    Colonel Jessep aka Col. Jessep

Support:   http://www.supcomuniverse.com/forum/ (Map Making Forum)
	

***************************

Enjoy!

