version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "Zarest V4",
    description = "",
    preview = '',
    map_version = 13,
    type = 'skirmish',
    starts = true,
    size = {1024, 1024},
    map = '/maps/Zarest_Winter.v0013/Zarest_Winter.scmap',
    save = '/maps/Zarest_Winter.v0013/Zarest_Winter_save.lua',
    script = '/maps/Zarest_Winter.v0013/Zarest_Winter_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
