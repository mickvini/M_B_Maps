version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "Master of the seas",
    description = "",
    preview = '',
    map_version = 4,
    type = 'skirmish',
    starts = true,
    size = {2048, 2048},
    reclaim = {327419.5, 79680},
    map = '/maps/Master_of_the_seas.v0004/Master_of_the_seas.scmap',
    save = '/maps/Master_of_the_seas.v0004/Master_of_the_seas_save.lua',
    script = '/maps/Master_of_the_seas.v0004/Master_of_the_seas_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6', 'ARMY_7', 'ARMY_8'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
