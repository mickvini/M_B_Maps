version = 3
ScenarioInfo = {
  name = 'Drakes_Ravine_4v4_V3',
  type = 'skirmish',
  description = '<LOC Drakes_Ravine_4v4_V3_Description>Named after a long-dead Imperial officer, Drake was sent in to quell a secessionist movement and found himself facing an organized army. He was forced to retreat to the opposite ridge of the ravine, and it was at that position he was able to get enough units online to fight back. Drake defeated the secessionists and the ravine has since borne his name.',
  starts = true,
  preview = '',
  size = {1024, 1024},
  norushradius = 100,
  norushoffsetX_ARMY_1 = 10,
  norushoffsetY_ARMY_1 = 0,
  norushoffsetX_ARMY_2 = -25,
  norushoffsetY_ARMY_2 = -5,
  norushoffsetX_ARMY_3 = -20,
  norushoffsetY_ARMY_3 = 35,
  norushoffsetX_ARMY_4 = 20,
  norushoffsetY_ARMY_4 = -15,
  norushoffsetX_ARMY_5 = 0,
  norushoffsetY_ARMY_5 = 0,
  norushoffsetX_ARMY_6 = 0,
  norushoffsetY_ARMY_6 = 0,
  norushoffsetX_ARMY_7 = 0,
  norushoffsetY_ARMY_7 = 0,
  norushoffsetX_ARMY_8 = 0,
  norushoffsetY_ARMY_8 = 0,
  map = '/maps/Drakes_Ravine_4v4_V3/Drakes_Ravine_4v4_V3.scmap',
  save = '/maps/Drakes_Ravine_4v4_V3/Drakes_Ravine_4v4_V3_save.lua',
  script = '/maps/Drakes_Ravine_4v4_V3/Drakes_Ravine_4v4_V3_script.lua',
  Configurations = {
    ['standard'] = {
      teams = {
        { name = 'FFA', armies = {'ARMY_1','ARMY_2','ARMY_3','ARMY_4','ARMY_5','ARMY_6','ARMY_7','ARMY_8',} },
      },
      customprops = {
        ['ExtraArmies'] = STRING( 'ARMY_9 NEUTRAL_CIVILIAN' ),
      },
    },
  }}
