version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "3x3_meat_grinder",
    description = "",
    preview = '',
    map_version = 5,
    AdaptiveMap = true,
    type = 'skirmish',
    starts = true,
    size = {2048, 2048},
    reclaim = {340453, 809245},
    map = '/maps/3x3_meat_grinder.v0005/3x3_meat_grinder.scmap',
    save = '/maps/3x3_meat_grinder.v0005/3x3_meat_grinder_save.lua',
    script = '/maps/3x3_meat_grinder.v0005/3x3_meat_grinder_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
