version = 3
ScenarioInfo = {
  name = 'Dawn_v2',
  description = '<LOC Dawn_v2_Description>Planet Dawn: This area was once the site of a great battle to rescue captured Aeon Loyalists from QAI. --- Level 2 of the Forged Alliance Campaign. Now a multiplayer map!  (AI markers included)',
  type = 'skirmish',
  starts = true,
  preview = '',
  size = {1024, 1024},
  map = '/maps/Dawn_v2/Dawn_v2.scmap',
  save = '/maps/Dawn_v2/Dawn_v2_save.lua',
  script = '/maps/Dawn_v2/Dawn_v2_script.lua',
  norushradius = 75,
  Configurations = {
    ['standard'] = {
      teams = {
        {
          name = 'FFA',
          armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6', 'ARMY_7', 'ARMY_8'},
        },
      },
      customprops = {
        ['ExtraArmies'] = STRING( 'ARMY_9 NEUTRAL_CIVILIAN' ),
      },
    },
  },
  norushoffsetX_ARMY_1 = 0,
  norushoffsetY_ARMY_1 = -3,
  norushoffsetX_ARMY_2 = 0,
  norushoffsetY_ARMY_2 = 0,
  norushoffsetX_ARMY_3 = 0,
  norushoffsetY_ARMY_3 = 0,
  norushoffsetX_ARMY_4 = 0,
  norushoffsetY_ARMY_4 = 0,
  norushoffsetX_ARMY_5 = 0,
  norushoffsetY_ARMY_5 = 0,
  norushoffsetX_ARMY_6 = 0,
  norushoffsetY_ARMY_6 = 0,
  norushoffsetX_ARMY_7 = -3,
  norushoffsetY_ARMY_7 = 4,
  norushoffsetX_ARMY_8 = -25,
  norushoffsetY_ARMY_8 = 18,
}
