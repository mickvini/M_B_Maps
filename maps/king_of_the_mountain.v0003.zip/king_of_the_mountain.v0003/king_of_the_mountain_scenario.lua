version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "king of the mountain",
    description = "",
    preview = '',
    map_version = 3,
    type = 'skirmish',
    starts = true,
    size = {2048, 2048},
    reclaim = {584861.3, 359346},
    map = '/maps/king_of_the_mountain.v0003/king_of_the_mountain.scmap',
    save = '/maps/king_of_the_mountain.v0003/king_of_the_mountain_save.lua',
    script = '/maps/king_of_the_mountain.v0003/king_of_the_mountain_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6', 'ARMY_7'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
