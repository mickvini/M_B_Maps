version = 3
ScenarioInfo = {
  name = 'Hrungdaks Dryland TeamPlayAI',
  description = '<LOC Hrungdaks Dryland TeamPlayAI_Description>TeamPlay 2 Humans in North verse 2 teamed Sorian Turtle AI in South. FA markers by AwarE.',
  type = 'skirmish',
  starts = true,
  preview = '',
  size = {2048, 2048},
  map = '/maps/Hrungdaks Dryland TeamPlayAI/Hrungdaks Dryland TeamPlayAI.scmap',
  save = '/maps/Hrungdaks Dryland TeamPlayAI/Hrungdaks Dryland TeamPlayAI_save.lua',
  script = '/maps/Hrungdaks Dryland TeamPlayAI/Hrungdaks Dryland TeamPlayAI_script.lua',
  norushradius = 190,
  Configurations = {
    ['standard'] = {
      teams = {
        {
          name = 'FFA',
          armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4'},
        },
      },
      customprops = {},
    },
  },
  norushoffsetX_ARMY_1 = 0,
  norushoffsetY_ARMY_1 = 0,
  norushoffsetX_ARMY_2 = 0,
  norushoffsetY_ARMY_2 = 0,
  norushoffsetX_ARMY_3 = 0,
  norushoffsetY_ARMY_3 = 0,
  norushoffsetX_ARMY_4 = 0,
  norushoffsetY_ARMY_4 = 0,
}
