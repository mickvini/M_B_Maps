version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "2x2 line",
    description = "",
    preview = '',
    map_version = 4,
    type = 'skirmish',
    starts = true,
    size = {1024, 1024},
    reclaim = {104136.5, 521090},
    map = '/maps/2x2_line.v0004/2x2_line.scmap',
    save = '/maps/2x2_line.v0004/2x2_line_save.lua',
    script = '/maps/2x2_line.v0004/2x2_line_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
