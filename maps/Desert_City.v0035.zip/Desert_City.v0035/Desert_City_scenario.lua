version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "Desert City",
    description = "",
    preview = '',
    map_version = 35,
    AdaptiveMap = true,
    type = 'skirmish',
    starts = true,
    size = {1024, 1024},
    reclaim = {186208.6, 5648.349},
    map = '/maps/Desert_City.v0035/Desert_City.scmap',
    save = '/maps/Desert_City.v0035/Desert_City_save.lua',
    script = '/maps/Desert_City.v0035/Desert_City_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6', 'ARMY_7', 'ARMY_8'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
