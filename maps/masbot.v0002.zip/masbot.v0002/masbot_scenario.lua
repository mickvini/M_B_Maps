version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "masbot",
    description = "",
    preview = '',
    map_version = 2,
    type = 'skirmish',
    starts = true,
    size = {2048, 2048},
    reclaim = {0, 0},
    map = '/maps/masbot.v0002/masbot.scmap',
    save = '/maps/masbot.v0002/masbot_save.lua',
    script = '/maps/masbot.v0002/masbot_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6', 'ARMY_7', 'ARMY_8'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
