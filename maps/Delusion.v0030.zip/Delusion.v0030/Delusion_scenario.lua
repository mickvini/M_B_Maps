version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "Delusion",
    description = "",
    preview = '',
    map_version = 30,
    type = 'skirmish',
    starts = true,
    size = {2048, 2048},
    reclaim = {268303.9, 91328},
    map = '/maps/Delusion.v0030/Delusion.scmap',
    save = '/maps/Delusion.v0030/Delusion_save.lua',
    script = '/maps/Delusion.v0030/Delusion_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6', 'ARMY_7'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
