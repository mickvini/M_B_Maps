version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "The Eye of Ra",
    description = "<LOC SCMP_IR021_Description>This serene citadel of stone sits passively on a peaceful ocean. Shake it to its very foundations!",
    preview = '',
    map_version = 5,
    type = 'skirmish',
    starts = true,
    size = {1024, 1024},
    reclaim = {20312.5, 0},
    map = '/maps/SCMP_IR021.v0005/SCMP_IR021.scmap',
    save = '/maps/SCMP_IR021.v0005/SCMP_IR021_save.lua',
    script = '/maps/SCMP_IR021.v0005/SCMP_IR021_script.lua',
    norushradius = 0,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6', 'ARMY_7', 'ARMY_8'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_9 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
