version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "The Lost Crater",
    description = "The Lost Crater by Kerbin. 20x20 on 8pl.",
    preview = '',
    map_version = 7,
    type = 'skirmish',
    starts = true,
    size = {1024, 1024},
    map = '/maps/The_Lost_Crater.v0007/The_Lost_Crater.scmap',
    save = '/maps/The_Lost_Crater.v0007/The_Lost_Crater_save.lua',
    script = '/maps/The_Lost_Crater.v0007/The_Lost_Crater_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6', 'ARMY_7', 'ARMY_8'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
