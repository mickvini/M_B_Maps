version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "Kerbal Island",
    description = "Kerbal Island 20x20 on 8pl by Kerbin & Yorh_Dev",
    preview = '',
    map_version = 3,
    type = 'skirmish',
    starts = true,
    size = {1024, 1024},
    reclaim = {20909.5, 110280},
    map = '/maps/Kerbal_Island.v0003/Kerbal_Island.scmap',
    save = '/maps/Kerbal_Island.v0003/Kerbal_Island_save.lua',
    script = '/maps/Kerbal_Island.v0003/Kerbal_Island_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'NewArmy1', 'NewArmy2', 'NewArmy3', 'NewArmy4', 'NewArmy5', 'NewArmy6', 'NewArmy7', 'NewArmy8'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'NewExtraArmy1' ),
            },
        },
    },
}
