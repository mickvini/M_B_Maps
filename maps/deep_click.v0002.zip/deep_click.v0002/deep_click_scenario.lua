version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "deep click",
    description = "",
    preview = '',
    map_version = 2,
    type = 'skirmish',
    starts = true,
    size = {1024, 1024},
    reclaim = {36565, 16005},
    map = '/maps/deep_click.v0002/deep_click.scmap',
    save = '/maps/deep_click.v0002/deep_click_save.lua',
    script = '/maps/deep_click.v0002/deep_click_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
