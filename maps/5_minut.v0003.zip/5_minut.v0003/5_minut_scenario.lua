version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "5 minut",
    description = "",
    preview = '',
    map_version = 3,
    type = 'skirmish',
    starts = true,
    size = {1024, 1024},
    reclaim = {38408, 184480},
    map = '/maps/5_minut.v0003/5_minut.scmap',
    save = '/maps/5_minut.v0003/5_minut_save.lua',
    script = '/maps/5_minut.v0003/5_minut_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
