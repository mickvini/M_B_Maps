version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "Double_trouble",
    description = "",
    preview = '',
    map_version = 3,
    type = 'skirmish',
    starts = true,
    size = {1024, 1024},
    reclaim = {29741, 179360},
    map = '/maps/Double_trouble.v0003/Double_trouble.scmap',
    save = '/maps/Double_trouble.v0003/Double_trouble_save.lua',
    script = '/maps/Double_trouble.v0003/Double_trouble_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
