version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "CraterCity",
    description = "",
    preview = '',
    map_version = 14,
    type = 'skirmish',
    starts = true,
    size = {1024, 1024},
    reclaim = {419188.5, 43080},
    map = '/maps/Crator_City(V0.2).v0014/Crator_City(V0.2).scmap',
    save = '/maps/Crator_City(V0.2).v0014/Crator_City(V0.2)_save.lua',
    script = '/maps/Crator_City(V0.2).v0014/Crator_City(V0.2)_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6', 'ARMY_7', 'ARMY_8'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
