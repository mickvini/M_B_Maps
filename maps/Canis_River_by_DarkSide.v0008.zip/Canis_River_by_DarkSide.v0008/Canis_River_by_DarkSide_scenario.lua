version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "Canis River by DarkSide",
    description = "",
    preview = '',
    map_version = 8,
    type = 'skirmish',
    starts = true,
    size = {1024, 1024},
    reclaim = {589577.5, 0},
    map = '/maps/Canis_River_by_DarkSide.v0008/Canis_River_by_DarkSide.scmap',
    save = '/maps/Canis_River_by_DarkSide.v0008/Canis_River_by_DarkSide_save.lua',
    script = '/maps/Canis_River_by_DarkSide.v0008/Canis_River_by_DarkSide_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6', 'ARMY_7', 'ARMY_8'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
