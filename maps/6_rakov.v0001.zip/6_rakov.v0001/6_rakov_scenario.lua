version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "6 rakov",
    description = "",
    preview = '',
    map_version = 1,
    type = 'skirmish',
    starts = true,
    size = {1024, 1024},
    reclaim = {0, 0},
    map = '/maps/6_rakov.v0001/6_rakov.scmap',
    save = '/maps/6_rakov.v0001/6_rakov_save.lua',
    script = '/maps/6_rakov.v0001/6_rakov_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
