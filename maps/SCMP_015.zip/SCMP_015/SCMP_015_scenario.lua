version = 3
ScenarioInfo = {
    name = 'Fields of Isis',
    description = '<LOC SCMP_015_Description>With almost no water and little vegetation, there is very little reason to come to the Fields. However, it does possess abundant Mass , which makes it a natural place for Commanders to fight.',
    type = 'skirmish',
    starts = true,
    preview = '/maps/SCMP_015/Isis_preview.jpg',
    size = {512, 512},
    map = '/maps/SCMP_015/SCMP_015.scmap',
    save = '/maps/SCMP_015/SCMP_015_save.lua',
    script = '/maps/SCMP_015/SCMP_015_script.lua',
    norushradius = 80.000000,
    norushoffsetX_ARMY_1 = 8.000000,
    norushoffsetY_ARMY_1 = -5.000000,
    norushoffsetX_ARMY_2 = -2.000000,
    norushoffsetY_ARMY_2 = 20.000000,
    norushoffsetX_ARMY_3 = -3.000000,
    norushoffsetY_ARMY_3 = 15.000000,
    norushoffsetX_ARMY_4 = -5.000000,
    norushoffsetY_ARMY_4 = -5.000000,
    Configurations = {
        ['standard'] = {
            teams = {
                { name = 'FFA', armies = {'ARMY_1','ARMY_2','ARMY_3','ARMY_4',} },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_9 NEUTRAL_CIVILIAN' ),
            },
        },
    }}
