version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "Kerbin Alliance v3",
    description = "Kerbin Alliance v3 by Kerbin",
    preview = '',
    map_version = 2,
    type = 'skirmish',
    starts = true,
    size = {1024, 1024},
    reclaim = {26170, 105478.8},
    map = '/maps/Kerbin_Alliance_v3.v0002/Kerbin_Alliance_v3.scmap',
    save = '/maps/Kerbin_Alliance_v3.v0002/Kerbin_Alliance_v3_save.lua',
    script = '/maps/Kerbin_Alliance_v3.v0002/Kerbin_Alliance_v3_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6', 'ARMY_7', 'ARMY_8'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
