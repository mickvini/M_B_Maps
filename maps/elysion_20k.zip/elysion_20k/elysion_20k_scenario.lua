version = 3
ScenarioInfo = {
  name = 'Elysion_20k',
  type = 'skirmish',
  description = '<LOC elysion_20k_Description>',
  starts = true,
  preview = '',
  size = {1024, 1024},
  norushradius = 80,
  norushoffsetX_ARMY_1 = 0,
  norushoffsetY_ARMY_1 = 0,
  norushoffsetX_ARMY_2 = 0,
  norushoffsetY_ARMY_2 = 0,
  norushoffsetX_ARMY_3 = 0,
  norushoffsetY_ARMY_3 = 0,
  norushoffsetX_ARMY_4 = 0,
  norushoffsetY_ARMY_4 = 0,
  norushoffsetX_ARMY_5 = 0,
  norushoffsetY_ARMY_5 = 0,
  norushoffsetX_ARMY_6 = 0,
  norushoffsetY_ARMY_6 = 0,
  norushoffsetX_ARMY_7 = 0,
  norushoffsetY_ARMY_7 = 0,
  norushoffsetX_ARMY_8 = 0,
  norushoffsetY_ARMY_8 = 0,
  map = '/maps/elysion_20k/elysion_20k.scmap',
  save = '/maps/elysion_20k/elysion_20k_save.lua',
  script = '/maps/elysion_20k/elysion_20k_script.lua',
  Configurations = {
    ['standard'] = {
      teams = {
        { name = 'FFA', armies = {'ARMY_1','ARMY_2','ARMY_3','ARMY_4','ARMY_5','ARMY_6','ARMY_7','ARMY_8',} },
      },
      customprops = {
        ['ExtraArmies'] = STRING( 'ARMY_9 NEUTRAL_CIVILIAN' ),
      },
    },
  }}
