version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "3Roads",
    description = "Made by LeoPhone",
    preview = '',
    map_version = 5,
    type = 'skirmish',
    starts = true,
    size = {1024, 1024},
    reclaim = {37360.3, 129858},
    map = '/maps/3Roads.v0005/3Roads.scmap',
    save = '/maps/3Roads.v0005/3Roads_save.lua',
    script = '/maps/3Roads.v0005/3Roads_script.lua',
    norushradius = 110,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6', 'ARMY_7', 'ARMY_8'}
                },
            },
            customprops = {
            },
        },
    },
}
