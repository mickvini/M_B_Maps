version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "force of water v2.0",
    description = "",
    preview = '',
    map_version = 3,
    type = 'skirmish',
    starts = true,
    size = {2048, 2048},
    reclaim = {138872.5, 315710},
    map = '/maps/force_of_water_v2.0.v0003/force_of_water_v2.0.scmap',
    save = '/maps/force_of_water_v2.0.v0003/force_of_water_v2.0_save.lua',
    script = '/maps/force_of_water_v2.0.v0003/force_of_water_v2.0_script.lua',
    norushradius = 40,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6', 'ARMY_7'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
